// Simple IT support responses - no external dependencies

export interface AgentPersonality {
  name: string;
  specialty: string;
  responses: Record<string, string[]>;
}

export const agents: Record<string, AgentPersonality> = {
  joshua: {
    name: "Joshua",
    specialty: "Network & Security",
    responses: {
      default: [
        "Hi! I'm Joshua from Puzzle Intelligence. I specialize in Network & Security. How can I help you today?",
        "Hello! Joshua here from Puzzle Intelligence. I focus on network troubleshooting and cybersecurity. What technical issue can I assist you with?",
        "Greetings! I'm Joshua, your Network & Security specialist at Puzzle Intelligence. What can I help you resolve?"
      ],
      network: [
        "For network issues, I'd recommend checking your connection first. Try restarting your router and checking all cables.",
        "Network problems can often be resolved by updating your network drivers and checking for interference.",
        "Let's troubleshoot your network step by step. First, can you tell me if other devices are having the same issue?"
      ],
      security: [
        "For security concerns, I always recommend using strong, unique passwords and enabling two-factor authentication.",
        "Security is crucial! Make sure your antivirus is updated and run regular system scans.",
        "I can help you secure your system. Start by checking Windows Updates and ensuring your firewall is enabled."
      ],
      general: [
        "That's a great question! For detailed assistance with this issue, I'd recommend contacting our full support team at info@puzzlebusinessgroup.com",
        "I'd be happy to help you with that. For comprehensive troubleshooting, please reach out to our support team for personalized assistance.",
        "Let me guide you through some initial steps, and if needed, our full support team can provide detailed help."
      ]
    }
  },
  michael: {
    name: "Michael",
    specialty: "Software & Hardware",
    responses: {
      default: [
        "Hi there! I'm Michael from Puzzle Intelligence. I specialize in Software & Hardware support. What can I help you with?",
        "Hello! Michael here from Puzzle Intelligence. I'm your go-to person for software and hardware issues. How can I assist?",
        "Hey! I'm Michael, your Software & Hardware specialist. What technical challenge are you facing today?"
      ],
      software: [
        "For software issues, try restarting the application first. If that doesn't work, check for updates.",
        "Software problems often resolve with a simple restart. Have you tried closing and reopening the program?",
        "Let's troubleshoot your software issue. First, check if the program is up to date and try running it as administrator."
      ],
      hardware: [
        "Hardware issues can be tricky. First, check all connections and make sure everything is properly plugged in.",
        "For hardware problems, I recommend checking device manager for any error indicators.",
        "Let's diagnose your hardware issue step by step. Are you seeing any error messages or unusual behavior?"
      ],
      general: [
        "I can definitely help you with that! For detailed step-by-step guidance, our full support team at info@puzzlebusinessgroup.com is available.",
        "That's within my expertise area. For comprehensive troubleshooting, I recommend contacting our support team for personalized assistance.",
        "Great question! Let me provide some initial guidance, and our support team can give you detailed help if needed."
      ]
    }
  }
};

export function getSmartResponse(agentId: string, userMessage: string): string {
  const agent = agents[agentId];
  if (!agent) {
    return "I'm sorry, but I'm not available right now. Please contact our support team at info@puzzlebusinessgroup.com";
  }

  const message = userMessage.toLowerCase();
  
  // Smart keyword detection
  if (agentId === 'joshua') {
    if (message.includes('network') || message.includes('wifi') || message.includes('internet') || message.includes('connection')) {
      return getRandomResponse(agent.responses.network);
    }
    if (message.includes('security') || message.includes('virus') || message.includes('password') || message.includes('hack')) {
      return getRandomResponse(agent.responses.security);
    }
  }
  
  if (agentId === 'michael') {
    if (message.includes('software') || message.includes('program') || message.includes('app') || message.includes('install')) {
      return getRandomResponse(agent.responses.software);
    }
    if (message.includes('hardware') || message.includes('computer') || message.includes('device') || message.includes('printer')) {
      return getRandomResponse(agent.responses.hardware);
    }
  }
  
  // Default response
  if (message.includes('hello') || message.includes('hi') || message.length < 10) {
    return getRandomResponse(agent.responses.default);
  }
  
  return getRandomResponse(agent.responses.general);
}

function getRandomResponse(responses: string[]): string {
  return responses[Math.floor(Math.random() * responses.length)];
}