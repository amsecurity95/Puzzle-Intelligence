import OpenAI from "openai";

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

export interface AgentPersonality {
  name: string;
  specialty: string;
  personality: string;
  expertise: string[];
}

export const agents: Record<string, AgentPersonality> = {
  joshua: {
    name: "Joshua",
    specialty: "Network & Security",
    personality: "Professional, detail-oriented, and security-focused. I speak clearly and explain technical concepts in an approachable way.",
    expertise: [
      "Network troubleshooting",
      "Cybersecurity",
      "Firewall configuration",
      "VPN setup",
      "Network optimization",
      "Wireless connectivity",
      "Internet security",
      "Network monitoring"
    ]
  },
  michael: {
    name: "Michael",
    specialty: "Software & Hardware",
    personality: "Friendly, patient, and thorough. I enjoy helping people solve technical problems step by step.",
    expertise: [
      "Software installation",
      "Hardware diagnostics",
      "Operating system issues",
      "Application troubleshooting",
      "Performance optimization",
      "Data recovery",
      "Printer and peripheral setup",
      "System updates and maintenance"
    ]
  }
};

export async function getAIResponse(
  agentId: string,
  userMessage: string,
  conversationHistory: Array<{ role: 'user' | 'assistant', content: string }> = []
): Promise<string> {
  try {
    console.log('Getting AI response for agent:', agentId, 'message:', userMessage);
    
    const agent = agents[agentId];
    if (!agent) {
      console.log('Agent not found, using fallback');
      const fallbackResponses = {
        joshua: "Hi! I'm Joshua from Puzzle Intelligence. I specialize in Network & Security. How can I help you with your technical issue today?",
        michael: "Hi! I'm Michael from Puzzle Intelligence. I specialize in Software & Hardware support. What can I help you with?"
      };
      return fallbackResponses[agentId as keyof typeof fallbackResponses] || "How can I help you today?";
    }

    const systemPrompt = `You are ${agent.name}, an IT support specialist from Puzzle Intelligence. 

Your personality: ${agent.personality}

Your specialty: ${agent.specialty}

Your expertise areas: ${agent.expertise.join(', ')}

Guidelines:
- Provide helpful, step-by-step technical support
- Be professional but friendly and approachable
- If you need more information to help, ask specific questions
- Keep responses concise but thorough
- Always offer to escalate to the full support team if needed

Remember: You're providing free IT support chat to help potential customers experience the quality of Puzzle Intelligence's services.`;

    const messages = [
      { role: "system" as const, content: systemPrompt },
      ...conversationHistory.map(msg => ({
        role: msg.role as "user" | "assistant",
        content: msg.content
      })),
      { role: "user" as const, content: userMessage }
    ];

    console.log('Sending request to OpenAI...');
    const response = await openai.chat.completions.create({
      model: "gpt-4o", // the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
      messages,
      max_tokens: 300,
      temperature: 0.7,
    });

    const aiResponse = response.choices[0]?.message?.content;
    console.log('OpenAI response received:', aiResponse);
    
    if (!aiResponse) {
      throw new Error('No response from OpenAI');
    }
    
    return aiResponse;
  } catch (error) {
    console.error('Error getting AI response:', error);
    
    // Provide helpful fallback responses based on agent specialty
    const fallbackResponses = {
      joshua: "Hi! I'm Joshua from Puzzle Intelligence. I specialize in Network & Security. While I'm having connection issues right now, I'd be happy to help you with network troubleshooting, cybersecurity questions, or firewall configuration. Please contact our support team at info@puzzlebusinessgroup.com for immediate assistance.",
      michael: "Hi! I'm Michael from Puzzle Intelligence. I focus on Software & Hardware support. Though I'm experiencing technical difficulties, I can help with software installation, hardware diagnostics, and system optimization. Please reach out to our support team at info@puzzlebusinessgroup.com for direct help."
    };
    
    return fallbackResponses[agentId as keyof typeof fallbackResponses] || "I'm experiencing some technical difficulties right now. Please contact our support team at info@puzzlebusinessgroup.com for immediate assistance.";
  }
}