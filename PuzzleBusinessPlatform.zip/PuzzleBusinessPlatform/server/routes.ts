import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertWaitlistSchema, insertContactSchema } from "@shared/schema";
import { getSmartResponse } from "./simple-support";
import { getAIResponse } from "./ai-support";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Health check endpoint - only for /health, not homepage
  app.get("/health", (req, res) => {
    res.status(200).send('OK');
  });

  // Waitlist endpoints
  app.post("/api/waitlist", async (req, res) => {
    try {
      const validatedData = insertWaitlistSchema.parse(req.body);
      const entry = await storage.createWaitlistEntry(validatedData);
      res.json({ success: true, entry });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to add to waitlist" });
      }
    }
  });

  app.get("/api/waitlist", async (req, res) => {
    try {
      const entries = await storage.getWaitlistEntries();
      res.json(entries);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch waitlist entries" });
    }
  });

  // Contact form endpoints
  app.post("/api/contact", async (req, res) => {
    try {
      const validatedData = insertContactSchema.parse(req.body);
      const message = await storage.createContactMessage(validatedData);
      res.json({ success: true, message });
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to send message" });
      }
    }
  });

  app.get("/api/contact", async (req, res) => {
    try {
      const messages = await storage.getContactMessages();
      res.json(messages);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch contact messages" });
    }
  });

  // AI Support Chat endpoint
  app.post("/api/ai-support", async (req, res) => {
    try {
      const { agentId, message, conversationHistory } = req.body;
      
      console.log('Received request:', { agentId, message });
      
      if (!agentId || !message) {
        return res.status(400).json({ error: "Agent ID and message are required" });
      }

      const aiResponse = getSmartResponse(agentId, message);
      console.log('Sending response:', aiResponse);
      
      res.json({ response: aiResponse });
    } catch (error) {
      console.error('AI Support error:', error);
      res.status(500).json({ error: "Failed to get AI response" });
    }
  });

  // Intelligent Support Chat endpoint with OpenAI
  app.post("/api/support-chat", async (req, res) => {
    try {
      console.log('Support chat request received:', req.body);
      const { message, agent } = req.body;
      
      if (!message || !agent) {
        console.log('Missing message or agent');
        return res.status(400).json({ error: "Message and agent are required" });
      }

      console.log('Calling getAIResponse with:', { agent, message });
      const aiResponse = await getAIResponse(agent, message, []);
      console.log('AI response generated:', aiResponse);
      
      res.json({ response: aiResponse });
    } catch (error) {
      console.error('Support chat error:', error);
      res.status(500).json({ error: "Failed to get AI response" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
